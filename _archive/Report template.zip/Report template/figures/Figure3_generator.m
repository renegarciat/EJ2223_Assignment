clear all;
close all;
clc;

f = 50;
w = 2*pi*f;
Ts = 100e-6;
Tw = 0.08;
N = Tw/Ts;
t = [0:N-1]*Ts;

s = cos(w.*t);

fid = fopen('Figure3.dat','w');

for k = 1:length(s)
    fprintf(fid,'%3.15f %3.15f\n',t(k),s(k));
end

fclose(fid);

system('C:\"Program Files"\gnuplot\bin\gnuplot Figure3.txt');