clear all;
close all;
clc;

f = 50;
w = 2*pi*f;
Ts = 100e-6;
Tw = 0.08;
N = Tw/Ts;
t = [0:N-1]*Ts;

s = cos(w.*t);

figure(1);
plot(t,s,'k-','LineWidth',2);
axis([0 Tw -1.5 1.5]);
grid on;
h = xlabel('Time $ t $ [s]');
set(h,'Interpreter','Latex');
h = ylabel('Voltage $ v_{q} $ [V]');
set(h,'Interpreter','Latex');
h = legend('$\cos(x)$','Location','Best');
set(h,'Interpreter','Latex');
h = gca;
set(h,'FontName','Times','FontSize',20);
print -r300 -depsc2 Figure1;
system('epstopdf Figure1.eps');